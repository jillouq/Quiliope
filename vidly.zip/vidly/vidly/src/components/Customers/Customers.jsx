import React, { Component } from 'react';
class Customers extends Component {
    render() {
        return <h1 className='ml-3'>Customers</h1>;
    }
}

export default Customers;
