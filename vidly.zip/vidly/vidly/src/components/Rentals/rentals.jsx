import React, { Component } from 'react';
class Rentals extends Component {
    render() {
        return <h1 className='ml-3'>Rentals</h1>;
    }
}

export default Rentals;
