import React, { Component } from 'react';

class MovieForm extends Form {
    state = {};
    render() {
        return <h1>Movie Form</h1>;
    }
}

export default MovieForm;
